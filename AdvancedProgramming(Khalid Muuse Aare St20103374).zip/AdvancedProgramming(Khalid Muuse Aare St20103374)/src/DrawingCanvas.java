  import java.awt.Graphics;
    import java.awt.*;
    import java.awt.event.*;
//import java.awt.image.BufferedImage;

import javax.swing.*;

    public class DrawingCanvas{
    	private static JTextField txtInput;
    	private static JTextField txtOutput;
    	private static JTextField txtConfidences;
        /**
         * @wbp.parser.entryPoint
         */
    	
        public static void NewScreen(){ 
   
    JFrame frame = new JFrame("Drawing On Canvas"); // title for the application window   

    Container content = frame.getContentPane();
    frame.getContentPane().setLayout(null); // set the frame for the canvas window
    final PadDraw drawPad = new PadDraw();      
    drawPad.setBounds(0, 110, 260, 200);

    content.add(drawPad);


    JPanel panel = new JPanel();
    panel.setBounds(0, 41, 260, 68);
    panel.setPreferredSize(new Dimension(100, 68));
    panel.setMinimumSize(new Dimension(100, 68));
    panel.setMaximumSize(new Dimension(100, 68));

    JButton redButton = new JButton("RED"); // red button to allow user to draw with red
    redButton.setFont(new Font("Arial", Font.BOLD, 13));
    redButton.setForeground(new Color(255, 0, 0));

    redButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            drawPad.red();
        }
    });

    JButton blueButton = new JButton("BLUE"); // blue button to allow user to draw with red
    blueButton.setFont(new Font("Arial", Font.BOLD, 13));
    blueButton.setForeground(Color.BLUE);

    blueButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            drawPad.blue();
        }
    });
    redButton.setPreferredSize(new Dimension(80, 20));
    blueButton.setPreferredSize(new Dimension(80, 20));
    panel.add(blueButton);
    
        JButton whiteButton = new JButton("WHITE");
        whiteButton.setForeground(Color.BLACK);
        whiteButton.setFont(new Font("Arial", Font.BOLD, 13));
        
            whiteButton.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    drawPad.white();
                }
            });
            
            
    panel.add(whiteButton);
    panel.add(redButton);


    content.add(panel);

    JRadioButton rdbtnPx = new JRadioButton("3 px");
    panel.add(rdbtnPx);

    JRadioButton rdbtnPx_1 = new JRadioButton("5 px");
    panel.add(rdbtnPx_1);

    JRadioButton rdbtnPx_2 = new JRadioButton("12 px");
    panel.add(rdbtnPx_2);


    ButtonGroup bg = new ButtonGroup();
    bg.add(rdbtnPx);
    bg.add(rdbtnPx_1);
    bg.add(rdbtnPx_2);

    rdbtnPx.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            drawPad.small();
        }
    });
    rdbtnPx_1.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            drawPad.medium();
        }
    });
    rdbtnPx_2.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            drawPad.big();
        }
    });
    
        JButton clearButton = new JButton("Clear Drawing"); // clear drawing button to clear the canvas area
        clearButton.setBounds(0, 321, 260, 27);
        frame.getContentPane().add(clearButton);
        clearButton.setBackground(Color.LIGHT_GRAY);
        clearButton.setFont(UIManager.getFont("TextArea.font"));
        
        txtInput = new JTextField();
        txtInput.setFont(new Font("Arial", Font.BOLD, 13));
        txtInput.setEditable(false);
        txtInput.setText("                         INPUT"); // title for the input i.e canvas area
        txtInput.setBounds(10, 10, 250, 20);
        frame.getContentPane().add(txtInput);
        txtInput.setColumns(10);
        
        txtOutput = new JTextField();
        txtOutput.setHorizontalAlignment(SwingConstants.CENTER); // alignment for the title "output"
        txtOutput.setText("OUTPUT");
        txtOutput.setFont(new Font("Arial", Font.BOLD, 13));
        txtOutput.setEditable(false);
        txtOutput.setColumns(10);
        txtOutput.setBounds(293, 10, 250, 20);
        frame.getContentPane().add(txtOutput);
        
        JButton btnScan = new JButton("Scan");
        btnScan.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        btnScan.setFont(new Font("Arial", Font.BOLD, 13));
        btnScan.setBounds(741, 378, 89, 23);
        frame.getContentPane().add(btnScan);
        
        txtConfidences = new JTextField();
        txtConfidences.setHorizontalAlignment(SwingConstants.CENTER);
        txtConfidences.setFont(new Font("Arial", Font.BOLD, 13));
        txtConfidences.setEditable(false);
        txtConfidences.setText("CONFIDENCES");
        txtConfidences.setBounds(575, 10, 216, 20); 
        frame.getContentPane().add(txtConfidences);
        txtConfidences.setColumns(10);

    clearButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            drawPad.clear();
        }
    });
    
    frame.setSize(856, 451);
    frame.setVisible(true);
}
}


class PadDraw extends JComponent{

private Image image;    
private Graphics2D graphics2D;  
private int currentX , currentY , oldX , oldY ; // The Mouse Coordinates

public PadDraw(){
    setDoubleBuffered(false);
    addMouseListener(new MouseAdapter(){
        public void mousePressed(MouseEvent e){ 
            oldX = e.getX();
            oldY = e.getY();
        } // It saves the coordinates of the area where the mouse is pressed
    });

    addMouseMotionListener(new MouseMotionAdapter(){
        public void mouseDragged(MouseEvent e){
            currentX = e.getX();
            currentY = e.getY();
            // It saves the coordinates when the mouse is dragged
            
            if(graphics2D != null)
            graphics2D.drawLine(oldX, oldY, currentX, currentY);
            repaint(); 
            // store current coordinates (x,y) as old (x,y)
            oldX = currentX;
            oldY = currentY;
        }

    });

}   

public void paintComponent(Graphics g){
    if(image == null){
        image = createImage(getSize().width, getSize().height);
        graphics2D = (Graphics2D)image.getGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        clear(); // clear the draw area

    }
    g.drawImage(image, 5, 5, null);
}

public void clear(){
    graphics2D.setPaint(Color.black);
    graphics2D.fillRect(0, 0, getSize().width, getSize().height);
    graphics2D.setPaint(Color.white);
    repaint();
}

public void red(){ // red paint for the canvas
    graphics2D.setPaint(Color.red);
    repaint();
}

public void white(){ // white paint for the canvas
    graphics2D.setPaint(Color.white);
    repaint();
}


public void blue(){ // blue paint for the canvas
    graphics2D.setPaint(Color.blue);
    repaint();
}

public void small(){ 
    graphics2D.setStroke(new BasicStroke(1));;
}
public void medium(){
    graphics2D.setStroke(new BasicStroke(5));;
}
public void big(){
    graphics2D.setStroke(new BasicStroke(12));;
}

}