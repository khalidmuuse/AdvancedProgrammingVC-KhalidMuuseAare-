import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;


public class ReadMNISTDatabase {
	
	
	
	String train_label_filename;
	String train_image_filename; // The name of the files are stored in a string since its in characters
	
    DataInputStream Label_data_stream = null;
	DataInputStream image_data_stream = null;
	
	ArrayList<int[][]> the_image_list; //Array list to store the image list
	ArrayList<Integer> the_Label_list; //Array list to store the label list
	
	
	public ReadMNISTDatabase(String imagePath, String labelPath){ // The format it reads the MNIST files
		train_label_filename = labelPath;
		train_image_filename = imagePath;
		
		the_image_list = new ArrayList<int[][]>();
		the_Label_list = new ArrayList<Integer>();
		
	}
	
	public ArrayList<int[][]> getImages() {
		return the_image_list; // To return the image list from the array list
	}
	public ArrayList<Integer> getLabels() {
		return the_Label_list; // To return the label list from the array list
	}
	
	public void readData () throws IOException  { 
		try {
			Label_data_stream = new DataInputStream(new FileInputStream(train_label_filename));
			image_data_stream = new DataInputStream(new FileInputStream(train_image_filename));
			
			int startcode_img = image_data_stream.readInt();
			int startcode_label = Label_data_stream.readInt();
			
			
			System.out.println("start code: images = " + startcode_img +
					
					" startcode labels= " + startcode_label); // To display the contents from reading the MNIST files in the console
			
			int number_of_images = image_data_stream.readInt();
			int number_of_labels = Label_data_stream.readInt();
			
			System.out.println("number of labels: " + number_of_labels +
					
					"number of images: " + number_of_images); // To display the contents from reading the MNIST files in the console
			
			int image_height = image_data_stream.readInt();
			int image_width = image_data_stream.readInt();
			
			System.out.println("image size: " + image_width +	" x " + image_height);
			
			int image_size = image_height * image_width;
			
			byte[]image_data = new byte[image_size * number_of_images];
			byte[]label_data = new byte[number_of_labels];
		
			Label_data_stream.read(label_data); 
			image_data_stream.read(image_data); 
			
			int [][] image; 
			//access individual images and labels.
			for(int i=0; i<number_of_images; i++)
			{
				
				int label = label_data[i];
				
				image = new int[image_width][image_height];
				
				for(int row = 0; row < image_height; row++) { // goes through each row
					for (int col = 0; col < image_width; col++) { // goes through each column
						image[row][col] = image_data[(i*image_height)+((row*image_width) + col)] ;
					}
				}
				the_image_list.add(image);
				the_Label_list.add(label);
			}
			
		}catch(FileNotFoundException e){
			System.out.print("file not found..." + e.toString()); // System will print out file not found if the file is not found 
		}
	}
}

