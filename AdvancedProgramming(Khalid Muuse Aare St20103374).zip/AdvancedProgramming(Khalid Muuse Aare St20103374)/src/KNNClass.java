import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class KNNClass{ 
	
	private ArrayList<String> fileList = new ArrayList<String>(); //Intended to store the file list in an array
    private ArrayList<BufferedImage> folderimageList = new ArrayList<BufferedImage>();
    
    private void buildFileList()
    {
       fileList.add( "\"F:\\MNIST test images-20190226\\test_images\\tmp\\0_1.png\"" ); 
       fileList.add( "\"F:\\MNIST test images-20190226\\test_images\\tmp\\0_21.png\"" );
       fileList.add( "\"F:\\MNIST test images-20190226\\test_images\\tmp\\0_21.png\"" );
    }

	private static final List ReadMNISTDatabase = null;

	public KNNClass() throws IOException {
		
		buildFileList();
	    loadImages();

		BufferedImage knownpicture = null; //Storing known image in a bufferedimage
		BufferedImage MNISTpictures = null; // Storing MNISTpictures in a bufferedimage
	
	ReadMNISTDatabase ReadMNISTDA = new ReadMNISTDatabase("MNIST/train-images.idx3-ubyte", "MNIST/train-labels.idx1-ubyte");
	try {
		ReadMNISTDA.readData();
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} // linking this class to the ReadMNISTDatabase class
	
	ArrayList<int[][]> image_list = ReadMNISTDA.getImages(); // Storing image list in an array list
	ArrayList<Integer> Label_list = ReadMNISTDA.getLabels(); // Storing label list in an array list
	
//int [] image_data = new int[image_width * image_height];
//myPicture.getRGB(0, 0, image_width)

//	ReadMNISTDatabase img_handler = new ReadMNISTDatabase(); 
	
//	BufferedImage knownpicture = img_handler.readData(""); 
//	BufferedImage MNISTpictures = img_handler.readData("");
	
for (int [][] theimage_list : image_list) {	// This for loop goes through every images rows and coloumns, repeats the two for loops inside this for loop
	for (int col = 0; col < knownpicture.getHeight(); col++ ) { // This for loop goes through the columns of an image
		for (int row =0; row < MNISTpictures.getWidth(); row++ ) { // This for loop goes through the rows of an image
		

		int pixel = knownpicture.getRGB(row, col);
		
		int alpha = (pixel >> 24) & 0xff;
		int red = (pixel >> 16) & 0xff;
		int green = (pixel >> 8) & 0xff;
		int blue = (pixel) & 0xff;

		int grayscale_org = (int) ((0.3 * red) + (0.59 * green) + (0.11 * blue));
		
		int pixel2 = MNISTpictures.getRGB(row, col);
		
		alpha = (pixel2 >> 24) & 0xff;
		red = (pixel2 >> 16) & 0xff;
		green = (pixel2) & 0xff;
		blue = (pixel2) & 0xff;
		
		int grayscale_compressed = (int) ((0.3 * red) + (0.59 * green) + (0.11 * blue));
		
		double squared_sum = (Math.pow((pixel - pixel2), 2)); // this calculates the distance between two images
		Math.sqrt(squared_sum);
		
		Collections.sort(ReadMNISTDatabase, new Comparator<ReadMNISTDatabase>() { // Attempted to sort the distance

			@Override
			public int compare(ReadMNISTDatabase o1, ReadMNISTDatabase o2) {
				// TODO Auto-generated method stub
				return 0;
			//	return (int) (o1.getImages() - o2.getLabels()); 
			}
		});	
		}
				}
			}
		}
	}
