import java.io.IOException;
import java.util.ArrayList;

public class StoreDistanceAndLabelOfImages implements Distance {
	
	
	
	public double getDistance (final double[] features1, final double[] features2) {
		double sum = 0;
		for (int i = 0; i < features1.length; i++)
			sum+= Math.pow(features1[i] - features2[i], 2);
		return Math.sqrt(sum);

	}
		public static void main(String[] args) {
			
			ArrayList<KNNClass> sortdistancelabel = new ArrayList<KNNClass>();
			ArrayList<KNNClass> sorteddistancelabel = new ArrayList (sortdistancelabel); // Attempted to keep a track of the calculated distance in the KNNClass by storing them in an array list

		//	sorteddistancelabel
		}
}
	
//		public static StoreDistanceAndLabel calcDistance(StoreDistanceAndLabel im,KNNClass ts) {
	
//	return null; 
	
//		}

		
		
			
			


