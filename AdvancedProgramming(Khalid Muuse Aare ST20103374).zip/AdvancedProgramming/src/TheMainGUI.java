import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JTextField;
//import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Image;
//import java.awt.Canvas;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.SwingConstants;

public class TheMainGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	JLabel label;
	private JFrame frame; 
	private JTextField txtImage;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TheMainGUI frame = new TheMainGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TheMainGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // the window will close once you click the button in the top right
		setBounds(100, 100, 640, 547); // area for the application window
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBackground(Color.WHITE);
		textField.setEditable(false);
		textField.setBounds(44, 70, 372, 26);
		contentPane.add(textField);
		textField.setColumns(10);
	
		label = new JLabel();
		label.setBounds(34, 176, 470, 250);
		getContentPane().add(label);
		
		JButton btnAttach = new JButton("Attach"); //Attach button on GUI
		btnAttach.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { //Functions for the button
				JFileChooser file = new JFileChooser();
				file.setCurrentDirectory(new File(System.getProperty("user.home")));
				FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg", "gif", "png"); //The types of files it can read
				file.addChoosableFileFilter(filter);
				int result = file.showSaveDialog(null);
				if(result == JFileChooser.APPROVE_OPTION) {
					File selectedFile = file.getSelectedFile();
					String path = selectedFile.getAbsolutePath();
					label.setIcon(ResizeImage(path));
					
				}
				else if(result == JFileChooser.CANCEL_OPTION) {
					System.out.println("File has not been selected"); //The system will print this out if no file has been selected
				}
			}
			});
			
		frame = new JFrame();
		
		JButton btnCanvas = new JButton("Canvas"); // Canvas button
		btnCanvas.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			DrawingCanvas nw = new DrawingCanvas(); //Created an object to call the "DrawingCanvas" class as it contains the canvas code
			nw.NewScreen(); //Opens a new window
			}
		});
		btnCanvas.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnCanvas.setBounds(44, 450, 89, 23); // area for the button on the application window
		contentPane.add(btnCanvas);	
		
		btnAttach.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnAttach.setBounds(474, 71, 89, 23);
		contentPane.add(btnAttach);
		
		JLabel lblRecogniseHandwritten = new JLabel("            Recognise HandWritten Digits");
		lblRecogniseHandwritten.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblRecogniseHandwritten.setBounds(158, 11, 291, 48);
		contentPane.add(lblRecogniseHandwritten);
		
		JButton btnUpload = new JButton("Read MNIST Files");
		btnUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReadMNISTDatabase RMNISTD = new ReadMNISTDatabase("MNIST/train-images.idx3-ubyte", "MNIST/train-labels.idx1-ubyte");//The format it reads the MNIST Files  
				try {
					RMNISTD.readData();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} // Created an object to call the "readData" method in the "ReadMNISTDatabase" class as it contains all the code to read the MNIST Files
		});
		btnUpload.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnUpload.setBounds(416, 112, 147, 23);
		contentPane.add(btnUpload);
		
		txtImage = new JTextField();
		txtImage.setHorizontalAlignment(SwingConstants.CENTER);
		txtImage.setFont(new Font("Arial", Font.BOLD, 13));
		txtImage.setEditable(false);
		txtImage.setText("Image:");
		txtImage.setBounds(44, 145, 86, 20);
		contentPane.add(txtImage);
		txtImage.setColumns(10);
		
	}
	
	public ImageIcon ResizeImage (String ImagePath) {
		 
		 ImageIcon AI = new ImageIcon(ImagePath);
		 Image img = AI.getImage();
		 Image newImg = img.getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
		 ImageIcon image = new ImageIcon(newImg);
		 return image;
		 
		} // This is to display the chosen image via the file chooser onto the main GUI
	}
